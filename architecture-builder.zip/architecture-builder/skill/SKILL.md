# 功能架构图生成器 Skill

## 概述

这是一个通用的功能架构图生成工具，可以将 JSON 配置转化为可视化的架构图，支持在线编辑、拖拽调整、导出图片/PPT 等功能。

## 功能特性

### 1. 多类型层级支持
- **模块层 (module)**: 最上层的功能入口展示
- **能力层 (capability)**: 支持分组的业务能力展示（核心）
- **流程层 (process)**: 业务流程节点横向排列
- **组件层 (component)**: 技术组件展示
- **数据层 (data)**: 数据来源/处理展示

### 2. 能力容器灵活配置
- **列数调整**: 每个能力组内的能力项支持 1-5 列排列
- **宽度倍数**: 支持 1-6 倍宽度，解决内容过多显示不全的问题
- **动态布局**: 自动计算总宽度，超出配置列数时自动换行

### 3. 在线编辑功能
- 点击任意卡片文字即可修改内容
- 点击层级标签可修改层级名称
- 点击能力组标题可修改组名称

### 4. 拖拽排序
- 支持层级之间拖拽调整顺序
- 支持同层级内卡片拖拽排序
- 支持能力组之间拖拽调整顺序

### 5. 配置面板
- **颜色配置**: 主题色、背景色、边框色自定义
- **字体配置**: 字体、字号、字重调整
- **间距配置**: 卡片间距、层级间距、内边距调节
- **布局配置**: 每行最大卡片数、宽度倍数

### 6. 导出功能
- 导出为 PNG 图片（高清 2x）
- 复制到剪贴板（直接粘贴到 PPT）
- 导出 PPTX 文件
- 下载/上传 JSON 配置文件

### 7. 画布调整
- 支持手动拖拽调整画布大小
- 右下角拖拽手柄，精确控制尺寸

## 使用方法

### 快速开始
1. 打开 `src/architecture-builder.html`
2. 右侧面板加载默认配置
3. 点击卡片开始编辑
4. 拖拽调整布局
5. 导出保存

### JSON 配置导入
```javascript
// 将你的 JSON 配置粘贴到右侧配置面板的文本框
// 点击"加载"按钮即可渲染
```

## 目录结构

```
architecture-builder/
├── skill/
│   └── SKILL.md              # 本文件：Skill 说明文档
├── src/
│   ├── architecture-builder.html    # 主程序文件
│   └── templates/
│       └── architecture-config-template.json  # 配置模板
├── examples/
│   └── project-management-architecture.json  # 示例配置
└── docs/
    └── agent-prompt.md          # 智能体提示词（用于AI生成配置）
```

## JSON 配置规范

### 完整结构
```json
{
  "title": "架构图标题",
  "config": {
    "font": { "family": "...", "size": 12, "weight": 700 },
    "colors": { "primary": "#C00000", "background": "#FFFFFF", "border": "#E5E7EB" },
    "spacing": { "gridGap": 12, "layerGap": 20, "layerPadding": 18 },
    "layout": {
      "capabilityColumns": 7,
      "processColumns": 5,
      "componentColumns": 3,
      "dataColumns": 5,
      "moduleColumns": 5
    }
  },
  "layers": [
    {
      "type": "module",
      "name": "层级名称",
      "columns": 5,
      "items": ["项1", "项2", "项3"]
    }
  ]
}
```

### 能力层特殊配置
```json
{
  "type": "capability",
  "name": "能力层",
  "items": [
    {
      "name": "能力组名称",
      "columns": 3,           // 内部排列列数 (1-5)
      "widthMultiplier": 2,   // 容器宽度倍数 (1-6)
      "items": ["能力项1", "能力项2"]
    }
  ]
}
```

## 智能体集成

本 Skill 配合 `docs/agent-prompt.md` 使用，可以让 AI 智能体：
1. 理解用户的业务需求描述
2. 自动生成符合规范的 JSON 配置
3. 直接导入本工具渲染

## 技术栈

- 纯 HTML/CSS/JavaScript（无需构建工具）
- html2canvas: 截图导出
- pptxgenjs: PPT 导出
- CSS Grid: 响应式布局

## 浏览器支持

- Chrome/Edge (推荐)
- Firefox
- Safari

## 更新日志

### v1.0.0
- 初始版本发布
- 支持5种层级类型
- 支持能力容器宽度倍数配置
- 支持画布拖拽调整大小
- 支持所有元素点击编辑